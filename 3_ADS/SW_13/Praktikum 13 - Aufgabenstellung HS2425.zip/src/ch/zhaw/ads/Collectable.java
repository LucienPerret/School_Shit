package ch.zhaw.ads;

public interface Collectable {
   void setMark(boolean b);
   boolean isMarked();
}
