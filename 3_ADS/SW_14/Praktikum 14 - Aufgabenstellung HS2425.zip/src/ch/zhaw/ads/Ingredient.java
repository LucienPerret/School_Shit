package ch.zhaw.ads;

public class Ingredient {
    private final String name;
    private final float gramInBakery;
    private float gramUsedForBaking;

    Ingredient (String name, int gramInBakery) {
        this.name = name;
        this.gramInBakery = gramInBakery;
    }

    void initialiseStockBeforeCooking() {
        gramUsedForBaking = 0;
    }

    boolean removeFromStock(float gramToRemove) {
        gramUsedForBaking += gramToRemove;
        return gramUsedForBaking <= gramInBakery;
    }

    String getRemainingStock() {
        return name + ": " + (gramInBakery - gramUsedForBaking) + ", ";
    }
}
