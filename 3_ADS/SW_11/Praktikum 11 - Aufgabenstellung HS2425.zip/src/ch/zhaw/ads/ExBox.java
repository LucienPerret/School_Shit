package ch.zhaw.ads;

/**
 * @author K. Rege
 * @version 1.0 -- Experimentierkasten
 */
public class ExBox {
    public static void main(String[] args) {
        ExBoxFrame f = new ExBoxFrame();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }
}